# Quick start

## 1.mysql

``` 
1.新建数据库：smart-admin-dev
2.运行sql文件：smart-admin-service\smart-admin-api\src\main\resources\sql\smart-admin-dev.sql
```

## 2.前端

``` 
1.cmd管理员身份进入 smart-admin-web ，执行npm install安装依赖
2.npm run local 启动
```

## 3.后端

``` 
1.eclipse导入项目，修改配置文件 java/resources/dev/application.properties 内的mysql连接属性与redis连接属性
```

## 4.参考文献：

[SmartAdmin 文档 (1024lab.net)](http://smartadmin.1024lab.net/doc/2/168)

