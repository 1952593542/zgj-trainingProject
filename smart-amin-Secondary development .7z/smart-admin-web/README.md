### 启动讲解

###### 配置vscode
将 /vscode/settings.json文件配置到vscode中

###### 启动
1 安装依赖：

`npm install`

2 运行本地环境

`npm run local`