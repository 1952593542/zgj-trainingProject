export const NOTICE_STATUS = {
  YES: {
    value: 1,
    desc: '是'
  },
  NO: {
    value: 0,
    desc: '否'
  }
};
export default {
  NOTICE_STATUS
};
