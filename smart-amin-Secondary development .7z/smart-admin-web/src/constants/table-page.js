
/**
 * table分页 每页条数切换的配置
 */
export const PAGE_SIZE_OPTIONS = [10,20,30,50,75,100,150,200,300,500,1000];

