export const PRIVILEGE_TYPE = {
  MENU: {
    value: 1,
    desc: '是'
  },
  POINTS: {
    value: 2,
    desc: '否'
  }
};
export default {
  PRIVILEGE_TYPE
};
