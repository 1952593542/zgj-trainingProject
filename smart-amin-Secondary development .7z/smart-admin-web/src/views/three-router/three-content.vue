<template>
  <Card class="warp-card" dis-hover>
    <Alert>
      <h3>三级路由页面</h3>
      <pre>
这个是三级路由页面。
      </pre>
    </Alert>
  </Card>
</template>

<script>
export default {
  name: 'ThreeContent',
  components: {},
  props: {},
  data() {
    return {
    };
  },
  mounted() {
  },
  methods: {
  }
};
</script>
