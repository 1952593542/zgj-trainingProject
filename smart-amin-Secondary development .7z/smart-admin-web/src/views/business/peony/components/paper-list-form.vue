<template>
  <div>
    <Form ref="form" :rules="formValidate" :label-width="90" :model="form">
          <FormItem label="state" prop="state" v-show="!isUpdate" >
            <Input v-model="form.state" />
          </FormItem>
          <FormItem label="paperNumber" prop="paperNumber" v-show="!isUpdate">
            <Input v-model="form.paperNumber" />
          </FormItem>
          <FormItem label="issuer" prop="issuer" v-show="!isUpdate">
            <Input v-model="form.issuer" />
          </FormItem>
          <FormItem label="faceValue" prop="faceValue">
            <Input v-model="form.faceValue" />
          </FormItem>
          <FormItem label="issueDateTime" prop="issueDateTime" v-show=false>
            <!-- <Input v-model="form.issueDateTime" /> -->
            <DatePicker type="datetime" 
            placeholder="Select date and time" style="width: 300px"        
            @on-change="form.issueDateTime=$event"
            value-format="yyyy-MM-dd HH:mm:ss"
            ></DatePicker>
          </FormItem>
          <FormItem label="maturityDateTime" prop="maturityDateTime" v-show="!isUpdate">
            <!-- <Input v-model="form.maturityDateTime" type="daterange"  /> -->
            <DatePicker type="datetime" 
            placeholder="Select date and time" style="width: 300px"        
            @on-change="form.maturityDateTime=$event"
            value-format="yyyy-MM-dd HH:mm:ss"
            ></DatePicker>
          </FormItem>
          <FormItem label="owner" prop="owner">
            <Input v-model="form.owner" />
          </FormItem>
    </Form>
    <Row class="code-row-bg" justify="end" type="flex">
      <Button @click="cancel" style="margin-right:10px">取消</Button>
      <Button @click="save" type="primary">保存</Button>
    </Row>
  </div>
</template>
<script>
  import { peonyApi } from '@/api/peony';
  import { paperApi } from '@/api/paper';
  export default {
    name: 'CodeReviewListForm',
    components: {
    },
    props: {
      //是否为更新表单  此处理解为发生购买
      isUpdate: {
        type: Boolean,
        default: true
      },
      //更新的表单数据对象
      updateData: {
        type: Object
      }
    },
    data() {
      return {
        //表单数据
        form: {
          state:null,
          paperNumber:null,
          issuer:null,
          faceValue:null,
          owner:null,
          // issueDateTime: ["",""],
          maturityDateTime: ["",""],
        },
        //表单验证
        formValidate: {
        state:[{ required: true, message: '请输入state', trigger: 'blur' }],
        paperNumber:[{ required: true, message: '请输入paperNumber', trigger: 'blur' }],
        issuer:[{ required: true, message: '请输入issuer', trigger: 'blur' }],
        faceValue:[{ required: true, message: '请输入faceValue', trigger: 'blur' }],
        owner:[{ required: true, message: '请输入owner', trigger: 'blur' }],
        // issueDateTime:[{ required: true, message: '请输入issueDateTime,格式: yyyy-MM-dd HH:mm:ss', trigger: 'blur' }],
        maturityDateTime:[{ required: true, message: '请输入maturityDateTime,格式: yyyy-MM-dd HH:mm:ss', trigger: 'blur' }],
        }
      };
    },
  watch: {
      updateData: function(newValue, oldValue) {
          this.$refs['form'].resetFields();
          if (this.isUpdate) {
              for (let k in this.form) {
                  this.$set(this.form, k, newValue[k]);
              }
              this.$set(this.form, 'id', newValue['id']);
          }
      },
      isUpdate: function(newValue, oldValue) {
          if (!newValue) {
              this.resetForm();
              this.$refs['form'].resetFields();
          }
      }
  },
    created() {},
    mounted() {},
    methods: {
      cancel() {
        this.$emit('on-form-close');
      },
      save() {
       this.$refs['form'].validate(valid => {
         if (valid) {
           if (this.isUpdate) {
            this.update();
           } else {
             this.add();
           }
         } else {
          this.$Message.error('参数验证错误，请仔细填写表单数据!');
         }
       });
      },
    resetForm() {
        this.form = {
          state:null,
          paperNumber:null,
          issuer:null,
          faceValue:null,
          owner:null,
          issueDateTime: ["",""],
          maturityDateTime: ["",""],
        };
        this.$refs['form'].resetFields();
      },
      async add() {
        this.$Spin.show();
        // let res = await peonyApi.addPeony(this.form);
        let res = await paperApi.issuePaper(this.form);
        this.$Message.success(res.msg);
        this.$Spin.hide();
        this.resetForm();
        this.$emit('on-form-close');
      },
      async update() {
        this.$Spin.show();
        // let res = await peonyApi.updatePeony(this.form);
        let res = await paperApi.buyPaper(this.form);
        this.$Message.success(res.msg);
        this.$Spin.hide();
        this.resetForm();
        this.$emit('on-form-close');
      }
    }
  };
</script>