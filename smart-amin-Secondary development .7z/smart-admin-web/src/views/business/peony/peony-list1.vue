<template>
    <div>
        <Card class="smart-query-card">
            <!------ 查询条件第一行 begin------->
            <!-- 本部分为页头 -->
            <Row class="smart-query-form-row">
                <span>
                    state :
                    <Input placeholder="请输入state" style="width: 150px" v-model="queryForm.state" />
                </span>
                <span>
                    paperNumber :
                    <Input placeholder="请输入paperNumber" style="width: 150px" v-model="queryForm.paperNumber" />
                </span>
                <span>
                    issuer :
                    <Input placeholder="请输入issuer" style="width: 150px" v-model="queryForm.issuer" />
                </span>
                <span>
                    owner :
                    <Input placeholder="请输入owner" style="width: 150px" v-model="queryForm.owner" />
                </span>
                <ButtonGroup>
                    <Button
                            @click="queryList"
                            icon="ios-search"
                            type="primary"
                            v-privilege="'peony1-list-query'"
                    >查询</Button>
                    <Button
                            @click="resetQueryList"
                            icon="md-refresh"
                            type="default"
                            v-privilege="'peony1-list-query'"
                    >重置</Button>
                </ButtonGroup>

                <Button
                        @click="showMoreQueryConditionFlag = !showMoreQueryConditionFlag"
                        icon="md-more"
                        style="margin-left: 20px"
                        type="primary"
                        v-privilege="'peony1-list-query'"
                >{{showMoreQueryConditionFlag?'隐藏':'展开'}}</Button>
            </Row>
            <!------ 查询条件第一行 begin------->

            <!------ 查询条件第二行 begin------->
            <Row class="smart-query-form-row" v-show="showMoreQueryConditionFlag">
                <span>
                  faceValue
                  <Input placeholder="请输入faceValue" style="width: 250px" v-model="queryForm.faceValue" />
                </span>
                <span>
                    maturityDateTime:
                    <DatePicker
                            placeholder="选择到期日期范围"
                            split-panels
                            style="width: 200px"
                            type="daterange"
                            v-model="queryForm.issueDateTime"
                    ></DatePicker>
                </span>
                <span>
                    issueDateTime:
                    <DatePicker
                            placeholder="选择issueDateTime Range"
                            split-panels
                            style="width: 200px"
                            type="daterange"
                            v-model="queryForm.maturityDateTime"
                    ></DatePicker>
                </span>
            </Row>
            <!------ 查询条件第二行 end------->
        </Card>

        <Card class="warp-card">
            <!-------操作按钮行 begin------->
            <Row class="marginBottom10">
                <Button
                        @click="showAddPeonyForm"
                        icon="md-add"
                        size="small"
                        type="primary"
                        v-privilege="'peony1-list-add'"
                >新建票据</Button>
                <!-- <Button @click="showBatchDeleteModal" class="marginLeft10" icon="ios-trash-outline" size="small" type="error" v-privilege="'peony-list-batch-delete'">批量删除</Button> -->

                <Button
                        :loading="allExportBtnLoading"
                        @click="exportAll"
                        class="marginLeft10 float-right"
                        icon="ios-cloud-download-outline"
                        size="small"
                        type="warning"
                        v-privilege="'peony1-list-export-all'"
                >导出全部</Button>

                <Button
                        :loading="batchExportBtnLoading"
                        @click="batchExport"
                        class="marginLeft10 float-right"
                        icon="ios-download-outline"
                        size="small"
                        type="warning"
                        v-privilege="'peony1-list-batch-export'"
                >批量导出</Button>

            </Row>
            <!-------操作按钮行 end------->

            <!-------表格列表 begin------->
            <Table
                    :columns="mainTable.columnArray"
                    :data="mainTable.data"
                    :loading="mainTable.loading"
                    @on-sort-change="handleSortChange"
                    border
                    highlight-row
                    ref="mainTable"
            >           
            </Table>
            <!-- 分页内容 -->
            <Page
                    :current="queryForm.pageNum"
                    :page-size="queryForm.pageSize"
                    :page-size-opts="mainTablePage.pageSizeOps"
                    :total="mainTablePage.total"
                    @on-change="changeMainTablePagePageNum"
                    @on-page-size-change="changeMainTablePagePageSize"
                    class="smart-query-table-page"
                    show-elevator
                    show-sizer
                    show-total
            />
        </Card>
        <!-------表格列表 end------->

        <!-- -----批量删除Modal begin----- -->
        <!-- <Modal title="批量删除" v-model="batchDeleteModal.show" width="450">
            <Form :label-width="80">
                <FormItem>
                    <h3 class="error-color">确定要删除以下数据吗？</h3>
                </FormItem>
                <FormItem label="删除数据">
                    <Card style="width:350px;height:250px;overflow-y:scroll;">
                        <ul>
                            <li v-for="item in mainTableSelectArray">
                                <a href="#">{{ item.id }}</a>
                            </li>
                        </ul>
                    </Card>
                </FormItem>
            </Form>
            <div slot="footer">
                <Button @click="batchDeleteModal.show = false" size="small" type="default">取消</Button>
                <Button @click="batchDelete" size="small" type="primary">确定删除</Button>
            </div>
        </Modal> -->
        <!-------批量删除Modal end------->

        <!-------添加、更新 Form表单 begin------->
        <Modal
                :footer-hide="true"
                :title="saveModal.isUpdate?'交易票据':'发行票据'"
                v-model="saveModal.show"
                @on-cancel="saveFormClose"
                width="500"
        >
            <!-- <PeonyListForm
                    :isUpdate="saveModal.isUpdate"
                    :updateData="saveModal.updateData"
                    @on-form-close="saveFormClose"
            /> -->
            <PaperListFrom
                :isUpdate="saveModal.isUpdate"
                :updateData="saveModal.updateData"
                @on-form-close="saveFormClose"
            />
        </Modal>
        <!-------添加、更新 Form表单 end------->
    </div>
</template>

<script>
    import {dateTimeRangeConvert} from '@/lib/util'
    import { PAGE_SIZE_OPTIONS } from '@/constants/table-page';
    import { peonyApi } from '@/api/peony';
    import PeonyListForm from './components/peony-list-form';
    import PaperListFrom from './components/paper-list-form';
    import { paperApi } from '@/api/paper';
    const PAGE_SIZE_INIT = 10;
    export default {
        name: 'PeonyList',
        components: {
                PeonyListForm,
                PaperListFrom
        },
        props: {},
        data() {
            return {
                /* -------------------------添加、更新表单 ------------------------- */
                saveModal: {
                    show: false,
                    isUpdate: false,
                    updateData: null
                },
                /* -------------------------批量操作------------------------- */
                //批量刪除彈出框 batchDeleteModal: {                   show: false                },
                //表格多选选中的元素数组
                mainTableSelectArray: [],
                /* -------------------------导出操作------------------------- */
                //批量导出loading按钮
                batchExportBtnLoading:false,
                //导出全部loading按钮
                allExportBtnLoading:false,
                /* -------------------------查询条件相关数据-------------------- */
                //搜索表单
                queryForm: {
                    state:null,
                    paperNumber:null,
                    issuer:null,
                    faceValue:null,
                    owner:null,
                    issueDateTime: ["",""],
                    maturityDateTime: ["",""],
                    pageNum: 1,
                    pageSize: PAGE_SIZE_INIT,
                    orders: []
                },
                //是否展示更多搜索条件
                showMoreQueryConditionFlag: false,
                /*  -------------------------表格相关数据------------------------- */
                //表格分页
                mainTablePage: {
                    total: 0,
                    pageSizeOps: PAGE_SIZE_OPTIONS
                },
                //表格
                mainTable: {
                    //加载中
                    loading: false,
                    //表格数据
                    data: [],
                    //表格列
                    columnArray: [
                        {
                            type: 'selection',
                            width: 30,
                            align: 'center'
                        },
                                                {
                            title: 'state',
                            key: 'state',
                            width: 100,
                            tableColumn: 't_paper.state',
                            sortable: 'custom'
                        },
                                                {
                            title: 'paperNumber',
                            key: 'paperNumber',
                            width: 130,
                            tableColumn: 't_paper.paper_Number',
                            sortable: 'custom'
                        },
                                                {
                            title: 'issuer',
                            key: 'issuer',
                            tableColumn: 't_paper.issuer',
                            sortable: 'custom'
                        },
                                                {
                            title: 'issueDateTime(UTC)',
                            key: 'issueDateTime',
                            tableColumn: 't_paper.issue_Date_Time',
                            sortable: 'custom'
                        },
                                                {
                            title: 'faceValue',
                            key: 'faceValue',
                            width: 120,
                            tableColumn: 't_paper.face_Value',
                            sortable: 'custom',
                        },
                                                {
                            title: 'maturityDateTime(UTC)',
                            key: 'maturityDateTime',
                            tableColumn: 't_paper.maturity_Date_Time',
                            sortable: 'custom'
                        },
                                                {
                            title: 'owner',
                            key: 'owner',
                            tableColumn: 't_paper.owner',
                            sortable: 'custom'
                        },
                                                {
                            title: '操作',
                            key: 'action',
                            align: 'right',
                            width: 130,
                            className: 'action-hide',
                            render: (h, params) => {
                                let actions = [
                                    {
                                        title: 'Trading',
                                        directives: [
                                            {
                                                name: 'privilege',
                                                value: 'peony1-list-update'
                                            }
                                        ],
                                        action: () => {
                                            this.showEditPeonyForm(params.row);
                                        }
                                    },
                                    {
                                        title: 'Redeem',
                                        directives: [
                                            {
                                                name: 'privilege',
                                                value: 'peony1-list-redeem'
                                            }
                                        ],
                                        action: () => {
                                            this.redeem(params.row);
                                        }
                                    }
                                ];
                                return this.$tableAction(h, actions);
                            }
                        }
                    ]
                }
            };
        },
        computed: {},
        watch: {},
        filters: {},
        created() {},
        mounted() {
            this.queryList();
        },
        beforeCreate() {},
        beforeMount() {},
        beforeUpdate() {},
        updated() {},
        beforeDestroy() {},
        destroyed() {},
        activated() {},
        methods: {
            /* -------------------------查询相关 begin------------------------- */
            convertQueryParam(){
                let issueDateTimeArray = dateTimeRangeConvert(this.queryForm.issueDateTime);
                let maturityDateTimeArray = dateTimeRangeConvert(this.queryForm.maturityDateTime);
                return {...this.queryForm,
                    issueDateTimeBegin:issueDateTimeArray[0],
                    issueDateTimeEnd:issueDateTimeArray[1],
                    maturityDateTimeBegin:maturityDateTimeArray[0],
                    maturityDateTimeEnd:maturityDateTimeArray[1]
                };
            },
            //查询
            async queryList() {
                this.mainTable.loading = true; //加载中
                try {
                    let params = this.convertQueryParam();
                    // let result = await peonyApi.queryPeony(params); // postAxios('/peony/page/query', data);
                    let result = await paperApi.queryPaper(params);
                    this.mainTable.data = result.data.list; // data用于分页等内容，list为 查询结果集
                    this.mainTablePage.total = result.data.total; // total为总记录数
                } finally {
                    this.mainTable.loading = false; //加载end
                }
            },
            //重置查询
            resetQueryList() {
                let pageSize = this.queryForm.pageSize;
                this.queryForm = {
                    state:null,
                    paperNumber:null,
                    issuer:null,
                    faceValue:null,
                    owner:null,
                    issueDateTime: ["",""],
                    maturityDateTime: ["",""],
                    pageNum: 1,
                    pageSize: pageSize,
                    orders: []
                };
                this.queryList();
            },
            //修改页码
            changeMainTablePagePageNum(pageNum) {
                this.queryForm.pageNum = pageNum;
                this.queryList();
            },
            //修改页大小
            changeMainTablePagePageSize(pageSize) {
                this.queryForm.pageNum = 1;
                this.queryForm.pageSize = pageSize;
                this.queryList();
            },
            //处理排序
            handleSortChange(column) {
                if (column.order === 'normal') {
                    this.queryForm.orders = [];
                } else {
                    this.queryForm.orders = [
                        {
                            column: column.column.tableColumn,
                            asc: 'asc' === column.order
                        }
                    ];
                }
                this.queryList();
            },
            /*-------------------------查询相关 end------------------------- */

            /*-------------------------批量操作 begin------------------------- */
            //显示批量删除弹窗
            // showBatchDeleteModal() {
            //     if (!this.validateMainTableSelection()) {
            //         return;
            //     }
            //     this.batchDeleteModal.show = true;
            // },
            //批量删除
            // async batchDelete() {
            //     this.$Spin.show();
            //     await peonyApi.batchDeletePeony(
            //             this.mainTableSelectArray.map(e => e.id)
            //     );
            //     this.batchDeleteModal.show = false;
            //     this.$Message.success('刪除成功');
            //     this.$Spin.hide();
            //     this.queryList();
            // },
            //清空选中
            clearMainTableSelection() {
                this.mainTableSelectArray = [];
            },
            //校验是否有选中
            validateMainTableSelection() {
                this.mainTableSelectArray = this.$refs.mainTable.getSelection();
                if (this.mainTableSelectArray.length < 1) {
                    this.$Message.error('请选择至少一条数据');
                    return false;
                }
                return true;
            },
            /*-------------------------批量操作 end------------------------- */

            /*-------------------------导入导出 begin------------------------- */
            //导出全部
            async exportAll(){
                try{
                    this.allExportBtnLoading = true;
                    let params = this.convertQueryParam();
                    await peonyApi.exportAll(params);
                }  catch(e){
                    console.log(e);
                }finally{
                    this.allExportBtnLoading = false;
                }
            },
            //批量导出
            async batchExport(){
                if (!this.validateMainTableSelection()) {
                    return;
                }
                try{
                    this.batchExportBtnLoading = true;
                    await peonyApi.batchExport(this.mainTableSelectArray.map(e => e.id));
                }  catch(e){
                    console.log(e);
                }finally{
                    this.batchExportBtnLoading = false;
                }
            },
            /*-------------------------导入导出 end------------------------- */

            /*-------------------------添加，修改 表单 begin------------------------- */
            //显示添加表单
            showAddPeonyForm() {
                this.saveModal.isUpdate = false;
                this.saveModal.show = true;
            },
            showEditPeonyForm(updateObject){
                this.saveModal.isUpdate =true;
                this.saveModal.updateData = updateObject;
                this.saveModal.show = true;
            },
            async redeem (redeemObject) {
                try {
                    // let res = await peonyApi.redeemPeony(redeemObject);
                    let res = await paperApi.redeemPaper(redeemObject);
                    this.$Modal.info({
                        content: res.msg
                    });
                } catch (err) {
                    this.$Modal.info({
                        content: err.data.msg
                    });                   
                }
                this.queryList();
            },
            async buyPaper (paperObject) {

                try {
                    let res = await paperApi.buyPaper(paperObject);
                    this.$Modal.info({
                        content: res.msg
                    });                   
                } catch (error) {
                   this.$Modal.info({
                        content: err.data.msg
                    });  
                }
            },
            saveFormClose(){
                this.saveModal.show = false;
                this.queryList();
            }
            /*-------------------------添加，修改 表单 end------------------------- */
        }
    };
</script>
