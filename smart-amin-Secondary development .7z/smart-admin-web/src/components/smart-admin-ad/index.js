import Ad from './ad.vue';
export default Ad;
