<template>
  <div style="text-align:center">
    <img src="http://smartadmin.1024lab.net/image/smart-admin-log-400@400.png"/>
    <p style="text-align:left;font-size:16px;margin-top:-40px">
        
   SmartAdmin由河南·洛阳 <a href="https://www.1024lab.net/" target="_blank">1024创新实验室</a>团队研发的一套互联网企业级的通用型中后台解决方案！使用SpringBoot和Vue，前后端分离。
    </p>
    <br/>
    <p style="text-align:left;font-size:16px">
     我们开源一套漂亮的代码和一套整洁的代码规范，让大家在这浮躁的代码世界里感受到一股把代码写好的清流！同时又让开发者节省大量的时间，减少加班，快乐工作，热爱生活。
    </p>
    <br/>
    <p style="text-align:left;font-size:20px">
      <font color="#DC143C"><strong>你的star 是我们最强的动力，感谢支持 ！(^_^)∠※   &nbsp;&nbsp;&nbsp;&nbsp; </strong></font>
     <a target="_blank" href="https://github.com/1024-lab/smart-admin">
      <img style="width: 82px;height: 20px;margin-right: 10px" alt="" src="https://img.shields.io/github/stars/1024-lab/smart-admin.svg?logo=github&style=social">
    </a>
    </p>
  </div>
</template>

<script>
export default {
  name: 'Ad',
  props: {
  },
  computed: {
  },
  mounted () {
  },
  methods: {
  }
};
</script>
