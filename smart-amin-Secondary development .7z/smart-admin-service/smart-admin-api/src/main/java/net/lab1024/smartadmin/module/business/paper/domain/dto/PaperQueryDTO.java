package net.lab1024.smartadmin.module.business.paper.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import net.lab1024.smartadmin.common.domain.PageParamDTO;
import java.util.Date;

@Data
public class PaperQueryDTO extends PageParamDTO{

	@ApiModelProperty("state")
	private String state;
	
	@ApiModelProperty("paperNumber")
	private String paperNumber;
	
	@ApiModelProperty("issuer")
	private String issuer;
	
	@ApiModelProperty("faceValue")
	private Long faceValue;
	
	@ApiModelProperty("owner")
	private String owner;
	
	@ApiModelProperty("issueDateTimeBegin")
	private Date issueDateTimeBegin;
	
	@ApiModelProperty("issueDateTimeEnd")
	private Date issueDateTimeEnd;
	
	@ApiModelProperty("maturityDateTimeBegin")
	private Date maturityDateTimeBegin;
	
	@ApiModelProperty("maturityDateTimeEnd")
	private Date maturityDateTimeEnd;
}
