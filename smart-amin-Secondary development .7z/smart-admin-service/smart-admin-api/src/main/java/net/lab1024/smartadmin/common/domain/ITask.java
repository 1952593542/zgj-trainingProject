package net.lab1024.smartadmin.common.domain;

/**
 * [  ]
 *
 * @author yandanyang
 * @version 1.0
 * @company 1024lab.net
 * @copyright (c) 2018 1024lab.netInc. All rights reserved.
 * @date 2019/4/13 0013 下午 14:23
 * @since JDK1.8
 */
public interface ITask {

    void execute(String paramJson) throws Exception;
}
