package net.lab1024.smartadmin.module.business.paper.domain.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.util.Date;

/**
 * 
 * @author 1952593542
 *
 */
@Data
public class PaperVo {
	
	@ApiModelProperty("state")
	private String state;
	
	@ApiModelProperty("paperNumber")
	private String paperNumber;
	
	@ApiModelProperty("issuer")
	private String issuer;
	
	@ApiModelProperty("issueDateTime")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date issueDateTime;
	
	@ApiModelProperty("faceValue")
	private Long faceValue;
	
	@ApiModelProperty("maturityDateTime")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date maturityDateTime;
	
	@ApiModelProperty("owner")
	private String owner;
}
