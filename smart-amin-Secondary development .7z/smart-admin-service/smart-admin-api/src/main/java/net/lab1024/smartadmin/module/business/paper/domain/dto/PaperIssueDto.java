package net.lab1024.smartadmin.module.business.paper.domain.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PaperIssueDto {

	@ApiModelProperty("state")
	private String state;
	
	@ApiModelProperty("paperNumber")
	private String paperNumber;
	
	@ApiModelProperty("issuer")
	private String issuer;
	
	@ApiModelProperty("faceValue")
	private Long faceValue;
	
	@ApiModelProperty("owner")
	private String owner;
	
	@ApiModelProperty("issueDateTime")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date issueDateTime;
	
	@ApiModelProperty("maturityDateTime")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date maturityDateTime;
}
