package net.lab1024.smartadmin.module.business.paper.domain.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import net.lab1024.smartadmin.common.domain.BaseEntity;

@Data
@TableName("t_paper")
public class PaperEntity extends BaseEntity{

	private String state;
	private String paperNumber;
	private String issuer;
	private String issueDateTime;
	private Long faceValue;
	private String maturityDateTime;
	private String owner;
}
