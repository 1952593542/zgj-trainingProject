package net.lab1024.smartadmin.module.business.paper.controller;

import org.apache.milagro.amcl.RSA2048.public_key;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import net.lab1024.smartadmin.common.controller.BaseController;
import net.lab1024.smartadmin.common.domain.PageResultDTO;
import net.lab1024.smartadmin.common.domain.ResponseDTO;
import net.lab1024.smartadmin.module.business.paper.domain.dto.PaperBuyDto;
import net.lab1024.smartadmin.module.business.paper.domain.dto.PaperIssueDto;
import net.lab1024.smartadmin.module.business.paper.domain.dto.PaperQueryDTO;
import net.lab1024.smartadmin.module.business.paper.domain.entity.PaperEntity;
import net.lab1024.smartadmin.module.business.paper.domain.vo.PaperVo;
import net.lab1024.smartadmin.module.business.paper.service.PaperService;

@RestController
@Api(tags = {"商业票据"})
public class PaperController extends BaseController{
	
	@Autowired
	private PaperService paperService;
	
	@PostMapping("/paper/query")
	@ApiOperation(value = "查询票据", notes = "@author zgj")
	public ResponseDTO<PageResultDTO<PaperVo>> queryByPage(@RequestBody PaperQueryDTO queryDTO) {
		
		return paperService.queryByPage(queryDTO);
	}
	
	@ApiOperation(value = "发行票据", notes = "@author zgj")
	@PostMapping("/paper/issue")
	public ResponseDTO<String> issue(@RequestBody @Validated PaperIssueDto issueDto) {
		return paperService.issue(issueDto);
	}
	
	@ApiOperation(value = "交易票据", notes = "@author zgj")
	@PostMapping("/paper/buy")
	public ResponseDTO<String> trading(@RequestBody @Validated PaperIssueDto tradingDto) {
		return paperService.trading(tradingDto);
	}
	
	@ApiOperation(value = "赎回票据", notes = "@author zgj")
	@PostMapping("/paper/redeem")
	public ResponseDTO<String> redeem(@RequestBody @Validated PaperIssueDto redeemDto) {
		return paperService.redeem(redeemDto);
	}
	
	
	
	
	
	
	
	
	
}
